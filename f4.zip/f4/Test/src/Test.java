import java.util.ArrayList;
import java.util.List;

public class Test {
  public static void main(String[] args) {
    List<E> colors= new ArrayList<E>();
    colors.add("yellow");
    colors.add("green");
    colors.add("red");
    colors.add("blue");
    if(colors.remove("red")) {
      colors.remove("green");
    }
    System.out.println(colors);
  }
}
