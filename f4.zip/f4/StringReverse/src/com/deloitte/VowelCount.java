package com.deloitte;

public class VowelCount{
	private int count;
	
	public VowelCount() {
	}
	
	public int doCount(String str) {
		count = 0;
		char[] str_array = str.toLowerCase().toCharArray();
		for(char temp : str_array) {
			if(temp == 'a' || temp == 'e' || temp == 'i' || temp == 'o' || temp == 'u') {
				count = count + 1;
			}
		}
		return count;
	}
}
