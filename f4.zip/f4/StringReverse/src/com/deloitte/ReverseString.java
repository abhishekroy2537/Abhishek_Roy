package com.deloitte;

public class ReverseString {
	private String str;
	
	public ReverseString() {
	}
	
	public ReverseString(String str) {
		this.str = str;
	}
	
	public String getStr() {
		return str;
	}


	public void setStr(String str) {
		this.str = str;
	}



	public String doReverse() {
		if(str == null) {
			return "Please set the String First";
		}
		String rev = "";
		char[] str_array = str.toCharArray();
		for(int i=str_array.length -1; i>=0; i--) {
			rev = rev + str_array[i];
		}
		return rev;
	}
	
}
