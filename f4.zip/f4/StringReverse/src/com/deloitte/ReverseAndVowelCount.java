package com.deloitte;

import java.util.Scanner;

public class ReverseAndVowelCount {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String below to be reversed and for Vowel Counts");
		String str = sc.nextLine();
		ReverseString revStr = new ReverseString();
		revStr.setStr(str);
		VowelCount vowCount = new VowelCount();
		System.out.println("Reversed String: " + revStr.doReverse());
		System.out.println("Vowel Count: " + vowCount.doCount(revStr.getStr()));
		sc.close();
	}

}
