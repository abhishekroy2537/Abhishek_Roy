
public class Emp {
	private int id;
	private String name;
	private long mobile;

	public Emp() {

	}

	public Emp(int i, String string, long l) {
		id = i;
		name = string;
		mobile = l;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	@Override
	public boolean equals(Object obj) {
		Emp comparedEmp = (Emp) obj;
		return comparedEmp.getId() == id && 
				comparedEmp.getName() == name && 
				comparedEmp.getMobile() == mobile;
	}

	@Override
	public String toString() {
		return id + " " + name + " " + mobile;
	}

	@Override
	protected void finalize() throws Throwable {
		super.finalize();
		System.out.println("emp finalize");
	}
	
	

}
