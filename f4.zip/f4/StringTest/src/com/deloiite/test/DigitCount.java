package com.deloiite.test;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DigitCount {
	private static String filename = "idvalues.txt";
	private Pattern pattern;
	private Matcher matcher;
	private String regex = "\\d{3}-\\d{2}-\\d{4}";

	public DigitCount() {
		pattern = Pattern.compile(regex);
		FileReader fr = null;
		BufferedReader br = null;
		String line = "";
		int valid_count = 0;
		try {
			fr = new FileReader(filename);
			br = new BufferedReader(fr);
			while ((line = br.readLine()) != null) {
				if (validate(line.trim())) {
					valid_count += 1;
				}
				System.out.println("ID : " + line + ", Valid : " + validate(line.trim()));
			}
			System.out.println("Valid Count is " + valid_count);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private boolean validate(String input) {
		matcher = pattern.matcher(input);
		return matcher.matches();
	}

	public static void main(String[] args) {
		new DigitCount();
	}
}
