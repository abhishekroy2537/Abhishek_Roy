package com.deloitte.dao;

import java.util.ArrayList;
import java.util.List;

import com.deloitte.main.Movie;

public class MovieDaoImpl implements MovieDao {
	private List<Movie> movieList = new ArrayList<>();
	@Override
	public boolean submitDetails(Movie movie) {
		movieList.add(movie);
		return true;
	}
	@Override
	public Movie getDetails(int id) {
		Movie mDetails = null;
		for(int i=0; i<movieList.size(); i++) {
			if(movieList.get(i).getId() == id) {
				mDetails = movieList.get(i);
			}
		}
		return mDetails;
	}
	
}
