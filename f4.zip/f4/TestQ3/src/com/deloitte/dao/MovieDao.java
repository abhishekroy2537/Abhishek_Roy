package com.deloitte.dao;

import com.deloitte.main.Movie;

public interface MovieDao {

	boolean submitDetails(Movie movie);

	Movie getDetails(int id);

}
