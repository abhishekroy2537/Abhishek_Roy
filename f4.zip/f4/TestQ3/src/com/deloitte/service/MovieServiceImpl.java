package com.deloitte.service;

import com.deloitte.dao.MovieDao;
import com.deloitte.dao.MovieDaoImpl;
import com.deloitte.main.Movie;

public class MovieServiceImpl implements MovieService{
	private MovieDao mDao;
	
	public  MovieServiceImpl() {
		mDao = new MovieDaoImpl();
	}
	
	@Override
	public boolean submitDetails(Movie movie) {
//		System.out.println("In Service");
		return mDao.submitDetails(movie);
	}

	@Override
	public Movie getDetails(int id) {
		return mDao.getDetails(id);
	}

}
