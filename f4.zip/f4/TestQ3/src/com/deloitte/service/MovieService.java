package com.deloitte.service;

import com.deloitte.main.Movie;

public interface MovieService {

	boolean submitDetails(Movie movie);

	Movie getDetails(int id);

}
