package com.deloitte.main;

import java.sql.Time;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.deloitte.service.MovieService;
import com.deloitte.service.MovieServiceImpl;

public class MovieMain {
	private MovieService mService;

	public MovieMain() {
		Scanner scan = new Scanner(System.in);
		int choice = 0;
		mService = new MovieServiceImpl();
		while (true) {
			choice = getChoice(scan);
			switch (choice) {
			case 1:
				System.out.println("Enter the Details Below");
				int id;
				String name;
				String showDate;
				String showTime;
				String status;
				boolean success = false;
				boolean notCorrect = true;
				do {
					try {
						System.out.println("Enter Id, name, showDate, showTime, Status(Available/Booked)");
						id = scan.nextInt();
						scan.nextLine();
						name = scan.nextLine();
						showDate = scan.nextLine();
						showTime = scan.nextLine();
						status = scan.nextLine();

						Movie movie = new Movie(id, name, showDate, showTime, status);
						success = mService.submitDetails(movie);
						System.out.println("Data Entered");
						notCorrect = false;
					} catch (InputMismatchException e) {
						System.out.println("Enter Correct Values");
					} catch (Exception e) {
						System.out.println("Exception Caught!!");
					}
				} while (notCorrect);
				break;
			case 2:
				System.out.println("Search Details");
				notCorrect = true;
				success = false;
				do {
					try {
						System.out.println("Enter the ID");
						id = scan.nextInt();
						Movie mDetails = mService.getDetails(id);
						if(mDetails == null) {
							System.out.println("No Record Found");
							System.out.println("Enter Again");
							notCorrect = true;
						}else {
							System.out.println(mDetails.toString());
							notCorrect = false;
						}
					} catch (InputMismatchException e) {
						System.out.println("Please Enter Correct Value");
					} catch (Exception e) {
						System.out.println("An Exception Encountered");
					}
				} while (notCorrect);
			case 3:
				System.out.println("Exiting the System");
				System.exit(0);
			default:
				break;
			}
		}
	}

	private int getChoice(Scanner scan) {
		int choice = 0;
		System.out.println("Movie Query System");
		System.out.println("1. Enter the Details");
		System.out.println("2. Search for a Movie Show");
		System.out.println("3. Exit System");
		try {
			choice = scan.nextInt();
		} catch (InputMismatchException e) {
			System.out.println("Please Enter a Valid Choice !!");
			scan.nextLine(); // Consume Keyboard Input
		}
		return choice;
	}

	public static void main(String[] args) {
		new MovieMain();
	}

}
