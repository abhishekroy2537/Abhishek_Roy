package com.deloitte.bean;

public class Employee {
	private int eid;
	private String name;
	private long mobile;
	private Address address;
	
	
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Employee(int eid, String name, long mobile, Address address) {
		super();
		this.eid = eid;
		this.name = name;
		this.mobile = mobile;
		this.address = address;
	}
	public Employee() {
		System.out.println("In Default Constructor");
	}
	public Employee(int eid, String name, long mobile) {
		System.out.println("In Constructor all Params");
		this.eid = eid;
		this.name = name;
		this.mobile = mobile;
	}
	

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", name=" + name + ", mobile=" + mobile + ", address=" + address + "]";
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getMobile() {
		return mobile;
	}
	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	
	
}
