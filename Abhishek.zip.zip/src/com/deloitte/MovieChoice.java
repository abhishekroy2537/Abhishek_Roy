
package com.deloitte;

import java.util.Comparator;

public class MovieChoice implements Comparator<Movie> {

	
	public Object selectFilm(int choice){
		switch (choice) {
		case 1:
			return MovieList.get(0);
			break;
		
		case 2:
			return MovieList.get(1);
			break;
		
		case 3:
			return MovieList.get(2);
			break;
	
		case 4:
			return MovieList.get(3);
			break;
	
		case 5:
			return MovieList.get(4);
			break;

		default:
			System.out.println("Enter a valid ID number");
		break;

	@Override
	public int compare(Movie o1, Movie o2) {
		// TODO Auto-generated method stub
		return 0;
	}
}