
package com.deloitte;
import java.util.*;


public class MovieList {

	public static void main(String[] args) {
		List<Movie> movieList=new ArrayList<>();
		movieList.add(new Movie(1 ,"Marjavaan", "07/03/2019", "13:40", "UnAvailable"));
		movieList.add(new Movie(2 , "Gully boy","03/03/2019", "08:45", "available"));
		movieList.add(new Movie(3 , "Good news","23/03/2019", "08:43", "Unavailable"));
		movieList.add(new Movie(4 , "Star wars","04/03/2019", "08:45", "Unavailable"));
		movieList.add(new Movie(5 , "dhoni","30/03/2019", "08:44", "Unavailable"));
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the movie ID");
		System.out.println("Enter 1 for Marjavaan");
		System.out.println("Enter 2 for Gully boy");
		System.out.println("Enter 3 for Good news");
		System.out.println("Enter 4 for Star wars");
		System.out.println("Enter 5 for dhoni");
		int choice=sc.nextInt();
		MovieChoice object=new MovieChoice();
		System.out.println(object.selectFilm(choice));
	}

	



}