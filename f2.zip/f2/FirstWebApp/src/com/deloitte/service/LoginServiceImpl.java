package com.deloitte.service;

import com.deloitte.bean.User;
import com.deloitte.dao.LoginDao;
import com.deloitte.dao.LoginDaoImpl;

public class LoginServiceImpl implements LoginService {
	private LoginDao lDao;
	
	public LoginServiceImpl() {
		lDao = new LoginDaoImpl();
	}
	@Override
	public String getUserType(User user) {
		// TODO Auto-generated method stub
		return lDao.getUserType(user);
	}
	@Override
	public void closeConnection() {
		lDao.closeConnection();
		
	}
	@Override
	public boolean addUser(User user) {
		// TODO Auto-generated method stub
		return lDao.addUser(user);
	}
	@Override
	public boolean checkLogin(String login) {
		// TODO Auto-generated method stub
		return lDao.checkLogin(login);
	}

}
