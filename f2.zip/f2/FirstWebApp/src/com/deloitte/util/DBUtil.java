package com.deloitte.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBUtil {
	private static Connection conn;

	public static Connection getConnection() {
		Properties props = new Properties();
		String DRIVER = "oracle.jdbc.driver.OracleDriver", URL = "jdbc:oracle:thin:@localhost:1521:xe",
				USER = "deloitte", PASSWORD = "del123";
		// HARD CODED DRIVER
		if (conn == null) {
			try {
				// Loaded Parameters
				Class.forName(DRIVER);
				conn = DriverManager.getConnection(URL, USER, PASSWORD);
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return conn;
		} else {
			return conn;
		}

	}

	public static void closeConnection() {
		try {
			if (conn != null)
				conn.close();
		} catch (SQLException e) {
		}
	}
}
