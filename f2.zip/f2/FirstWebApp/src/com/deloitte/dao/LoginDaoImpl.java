package com.deloitte.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.deloitte.bean.User;
import com.deloitte.util.DBUtil;

public class LoginDaoImpl implements LoginDao {

	@Override
	public String getUserType(User user) {
//		JDBC Code, Fetch Data from table for the login and Compare Password
//		If Authenticated return type
		String query = "select password, type from user_details where login = ?";
		Connection conn = DBUtil.getConnection();
		if (conn == null) {
			System.out.println("Connection is Null");
			return null;
		} else {
			System.out.println("Connection Established");
			try {
				PreparedStatement ps = conn.prepareStatement(query);
				ps.setString(1, user.getLogin());
				ResultSet rs = ps.executeQuery();
				if (rs.next()) {
					if (user.getPassword().equals(rs.getString(1))) {
						String type = rs.getString(2);
						user.setType(type);
						return type;
					} else {
						return null;
					}
				}
			} catch (SQLException e) {
				e.printStackTrace();
				return null;
			}
			return null;
		}
	}

	@Override
	public void closeConnection() {
		DBUtil.closeConnection();
	}

	@Override
	public boolean addUser(User user) {
		String query = "insert into user_details(login, password, type) values(?, ?, ?)";
		Connection conn = DBUtil.getConnection();
		if (conn == null) {
			System.out.println("No Connection Found");
			return false;
		} else {
			System.out.println("Connection Established");
			try {
				PreparedStatement stmt = conn.prepareStatement(query);
				stmt.setString(1, user.getLogin());
				stmt.setString(2, user.getPassword());
				stmt.setString(3, user.getType());
				int rows = stmt.executeUpdate();
				if(rows != -1) {
					System.out.println("Data Added");
					return true;
				}
				return false;
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
	}

	@Override
	public boolean checkLogin(String login) {
		String query = "select login from user_details where login = ?";
		Connection conn = DBUtil.getConnection();
		if(conn == null) {
			System.out.println("No Connection");
			return false;
		}else {
			System.out.println("Connection Established");
			try {
				PreparedStatement stmt = conn.prepareStatement(query);
				stmt.setString(1, login);
				ResultSet rs = stmt.executeQuery();
				if(rs.next()) {
					System.out.println("Got Login");
					return true;
				}else {
					System.out.println("No Login");
					return false;
				}
			} catch (SQLException e) {

				System.out.println("Got Login");
				e.printStackTrace();
				return false;
			}
		}
	}

}
