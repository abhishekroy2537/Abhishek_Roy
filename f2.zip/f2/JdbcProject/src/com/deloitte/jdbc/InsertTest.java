package com.deloitte.jdbc;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.Properties;
import java.util.Scanner;

public class InsertTest {
	public static void main(String[] args) {
		Properties props = new Properties();
		String DRIVER = "", URL = "", USER = "", PASSWORD = "";
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter <id> <name> <age> <desig> <dept>");
		Connection conn = null;
		String query = 
				"insert into employee(id, name, age, desig, dept) values (?, ?, ?, ?, ?)";
		try {
			props.load(new FileInputStream("db.config"));
			DRIVER = props.getProperty("DRIVER");
			URL = props.getProperty("URL");
			USER = props.getProperty("USER");
			PASSWORD = props.getProperty("PASSWORD");
			//JDBC
			Class.forName(DRIVER);
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setInt(1, scan.nextInt());
			stmt.setString(2, scan.next());
			stmt.setInt(3, scan.nextInt());
			stmt.setString(4, scan.next());
			stmt.setInt(5, scan.nextInt());
			int rows = stmt.executeUpdate();
			if(rows > 0) {
				System.out.println("Data Inserted");
			}else{
				System.out.println("Insert Failed");
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
