package com.deloitte.jdbc;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.Properties;
import java.util.Scanner;

public class InsertTestFile {
	public static void main(String[] args) {
		Properties props = new Properties();
		String DRIVER = "", URL = "", USER = "", PASSWORD = "";
		Scanner scan = new Scanner(System.in);
//		System.out.println("Enter <id> <name> <age> <desig> <dob> <dept>");
		Connection conn = null;
		String query = "insert into employee(id, name, age, desig, dept) values (?, ?, ?, ?, ?)";
		FileReader fr = null;
		BufferedReader br = null;
		String line = "";
		int rows = 0;
		try {
			props.load(new FileInputStream("db.config"));
			DRIVER = props.getProperty("DRIVER");
			URL = props.getProperty("URL");
			USER = props.getProperty("USER");
			PASSWORD = props.getProperty("PASSWORD");
			// JDBC
			Class.forName(DRIVER);
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
			PreparedStatement stmt = conn.prepareStatement(query);
			fr = new FileReader("Emp.txt");
			br = new BufferedReader(fr);
			while ((line = br.readLine()) != null) {
				String[] values = line.split(",");
				for (String string : values) {
					System.out.print(string);
				}
				System.out.println();
				stmt.setInt(1, Integer.parseInt(values[0]));
				stmt.setString(2, values[1]);
				stmt.setInt(3, Integer.parseInt(values[2]));
				stmt.setString(4, values[3]);
				stmt.setInt(5, Integer.parseInt(values[4]));
				rows += stmt.executeUpdate();
			}
			System.out.println("Rows : " + rows);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
