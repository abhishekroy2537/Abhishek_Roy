package com.deloitte;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class MyFileWriter {

	@SuppressWarnings("resource")
	public MyFileWriter() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter a Sentence");
		String line = scan.nextLine();
		File outFile = new File("output.txt"); // No Exception in creating File
		FileWriter fw = null;
		BufferedWriter bw = null;
		try {
			//fw = new FileWriter(outFile); // Overwrite // FileWriter will access the file in disk
			fw = new FileWriter(outFile, true); //Append to the text Already present
			bw = new BufferedWriter(fw);
			bw.write(line);// + delim);
			bw.newLine(); // Appending End Line Char
			System.out.println("Written to File");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (bw != null) {
				try {
					bw.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public static void main(String[] args) {
		new MyFileWriter();
	}

}
