package com.deloitte.emp;

import java.io.Serializable;

public class Emp implements Serializable, Cloneable {
	private static final long serialVersionUID = 1L;
	private int id;
	private String name;
	private long mobile;
	private String Designation;
	private Dept dept;

	public int getId() {
		return id;
	}

	public Dept getDept() {
		return dept;
	}

	public void setDept(Dept dept) {
		this.dept = dept;
	}

	public Emp(int id, String name, long mobile, String designation, Dept dept) {
		super();
		this.id = id;
		this.name = name;
		this.mobile = mobile;
		Designation = designation;
		this.dept = dept;
	}

	@Override
	public Object clone() throws CloneNotSupportedException {
		Emp clonedEmp = (Emp) super.clone();
		clonedEmp.dept = (Dept) clonedEmp.dept.clone();
		//deep cloning
		return clonedEmp;
	}

	public Emp() {

	}

	@Override
	public String toString() {
		return "[Id : " + id + " Name : " + name + ", Mobile : " + mobile + ", Designation : " + Designation + ", Dept : " + dept + "]";
	}

	public Emp(int id, String name, long mobile, String Designation) {
		super();
		this.id = id;
		this.name = name;
		this.mobile = mobile;
		this.Designation = Designation;
	}

	public String getDesignation() {
		return Designation;
	}

	public void setDesignation(String designation) {
		Designation = designation;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

}
