package com.deloitte.emp;

public class Dept implements Cloneable {
	private int id;
	private String dept;
	
	@Override
	public Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
	public Dept(int id, String dept) {
		super();
		this.id = id;
		this.dept = dept;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	@Override
	public String toString() {
		return "[" + "ID : " + id + ", Dept : " + dept + "]";
	}
	
}
