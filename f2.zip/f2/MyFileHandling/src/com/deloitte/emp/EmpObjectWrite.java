package com.deloitte.emp;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class EmpObjectWrite {

	public EmpObjectWrite() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter <ID> <Name> <Mobile> <Designation>");
		Emp emp = new Emp
				(scan.nextInt(), scan.next(), scan.nextLong(), scan.next());
		FileOutputStream fos = null;
		ObjectOutputStream oos = null; // Serialisation // Persistance Process
		try {
			fos = new FileOutputStream("emp.ser");
			oos = new ObjectOutputStream(fos);
			oos.writeObject(emp);
			System.out.println("Emp Object Wriiten to File");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if(fos != null) fos.close();
				if(oos != null) oos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) {
		new EmpObjectWrite();
	}

}
