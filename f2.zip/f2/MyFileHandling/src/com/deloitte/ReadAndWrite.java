package com.deloitte;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class ReadAndWrite {

	@SuppressWarnings({ "unused", "resource" })
	public ReadAndWrite() {
		Scanner scan = new Scanner(System.in);
		File fileRead = new File("output.txt");
		File fileOut = new File("output_transferred.txt");
		FileReader fr = null;
		FileWriter fw = null;
		BufferedReader br = null;
		BufferedWriter bw = null;
		String line = "";
		try {
			fr = new FileReader(fileRead);
			br = new BufferedReader(fr);
			fw = new FileWriter(fileOut);
			bw = new BufferedWriter(fw);
			while ((line = br.readLine()) != null) {
				bw.write(line);
				bw.newLine();
			}
			System.out.println("Successfully Copied!!");
		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			try {
				if(br != null) br.close();
				if(bw != null) bw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}

	public static void main(String[] args) {
		new ReadAndWrite();

	}

}
