package com.deloitte;

import com.deloitte.emp.Dept;
import com.deloitte.emp.Emp;

public class CloneTest {

	public CloneTest() {
		Emp emp = new Emp(111, "Ansh", 786L, "Tester", new Dept(988, "Sales"));
		Emp empClone = null;
		try {
			empClone = (Emp) emp.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		System.out.println("Clone");
		System.out.println(empClone);

		emp.getDept().setDept("HR");
		System.out.println(emp.getDept());
		System.out.println(empClone.getDept());
		System.out.println(emp.getDept() == empClone.getDept()); // Shallow Clonning
	}

	public static void main(String[] args) {
		new CloneTest();
	}

}
