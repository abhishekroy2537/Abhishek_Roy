package com.deloitte;

public class ReflectionTest {
	public static void main(String[] args) {
		System.out.println("Check");
	}
}
