package com.deloitte;

public interface Movable {
	void move();
}
