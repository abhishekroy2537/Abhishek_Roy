package com.deloitte.movable;

import com.deloitte.*;
//Implementing Design Pattern called Factory Pattern
public class MovableFactory {
	// Called Factory Method
	public static Movable getInstance(String type) {
		switch(type) {
		case "car":
			return new Car();
		case "bus":
			return new Bus();
		case "truck":
			return new Truck();
		case "Van":
			return new Van();
		default:
			return new Movable(){

				@Override
				public void move() {
					System.out.println("Anonymous Class");
				}
				
			};
		}
	}

}
