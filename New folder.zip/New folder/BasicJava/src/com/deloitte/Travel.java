package com.deloitte;

public class Travel {

	@SuppressWarnings("unused")
	public static void main(String[] args) {

		Car c1 = new Car();
		c1.setTyres(5);
		System.out.println("Car Tyres = " + c1.getTyres());

		Bus b1 = new Bus();
		b1.setTyres(7);
		System.out.println("Bus Tyres = " + b1.getTyres());

		Van v1 = new Van();
		Truck v2 = new Truck();

	}

}
