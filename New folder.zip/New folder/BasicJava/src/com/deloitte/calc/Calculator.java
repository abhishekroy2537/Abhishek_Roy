package com.deloitte.calc;

@FunctionalInterface
public interface Calculator {

	int calculate(int i, int j);
}
