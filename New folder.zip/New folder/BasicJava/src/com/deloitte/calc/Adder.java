package com.deloitte.calc;

public class Adder implements Calculator {

	@Override
	public int calculate(int first, int second) {
		return first + second;
	}

}
