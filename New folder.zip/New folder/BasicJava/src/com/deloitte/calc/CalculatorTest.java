package com.deloitte.calc;

public class CalculatorTest {
	public static void main(String[] args) {
		Calculator calc = new Adder();
		int sum = calc.calculate(45, 55);
		System.out.println("Sum = " + sum);
		calc = new Subtractor();
		//Print Difference
		//Calculator is a Interface
//		calc= new Calculator() {
//			
//			@Override
//			public int calculate(int first, int second) {
//				// TODO Auto-generated method stub
//				return first * second;
//			}
//		}; // Local Inner also Anonymous
		//Lambda Expression, implementation of anonymous class
		calc = (first, second)->first*second; //This is an implementation of a Method in Interface
		System.out.println(calc.calculate(1,8));
		calc = (first, second)->first/second;
		System.out.println(calc.calculate(8, 2));
	}
	
}
