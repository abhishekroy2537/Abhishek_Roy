package com.deloitte.calc;

public class Subtractor implements Calculator {

	@Override
	public int calculate(int i, int j) {
		// TODO Auto-generated method stub
		return i- j;
	}


}
