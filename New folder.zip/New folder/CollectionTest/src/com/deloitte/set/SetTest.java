package com.deloitte.set;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class SetTest {
//Set not ordered and no duplicates
	public static void main(String[] args) {
		Set<String> colorSet = new HashSet<>();
		String[] colorArray = { "Red", "Yellow", "Black", "White", "Red" };
		for (String color : colorArray) {
			System.out.println(colorSet.add(color));
		}
		System.out.println(colorSet);
		Set<String> colorTree = new TreeSet<>(colorSet); // Only Sets
		System.out.println(colorTree); // Inverted Tree
		
	}
}
