package com.deloitte.set;

import java.util.HashSet;
import java.util.Set;

import com.deloitte.Emp;

public class EmpSetTest {

	public static void main(String[] args) {
		Set<Emp> empSet = new HashSet<>();
		System.out.println("Adding Values");
		empSet.add(new Emp(112, "Anshul", 7868805672L));
		empSet.add(new Emp(111, "Anshu", 7868805673L));
		empSet.add(new Emp(113, "Ansh", 7868805674L));
		empSet.add(new Emp(114, "Ans", 7868805675L));
		empSet.add(new Emp(115, "An", 7868805676L));
		empSet.add(new Emp(116, "A", 7868805677L));
		empSet.add(new Emp(116, "A", 7868805677L));
//Similar objects will also come.... Since hash is used means address. 
		System.out.println(empSet);
	}

}
