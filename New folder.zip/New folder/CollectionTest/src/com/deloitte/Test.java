package com.deloitte;

public class Test
{
   static int age=25;
   Test() { }
   public static void main(String[] args) {
          Test t1 = new Test();
          Test t2 = new Test();
	t1.age++;
	System.out.print("Age of t1 = "+ t1.age++ );
	System.out.println(" Age of t2 = "+ t2.age++ );
   }
}
