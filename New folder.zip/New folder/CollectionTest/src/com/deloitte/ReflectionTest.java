package com.deloitte;

import java.lang.reflect.Method;

public class ReflectionTest {
	public static void main(String[] args) {
		MyFileReader mfr  = new MyFileReader();
		String className = mfr.getName().split(",")[0];
		String name = mfr.getName().split(",")[1];
		try {
			Class objClass =  Class.forName(className);
			Emp emp = (Emp) objClass.newInstance();
			emp.setName(name);
			System.out.println(emp);
//			Method[] meths = objClass.getMethods();
//			for (Method method : meths) {
//				System.out.println(method);
//			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (InstantiationException e) { //If the class is abstract
			e.printStackTrace();
		} catch (IllegalAccessException e) { //If Constructor is Private
			e.printStackTrace();
		}
	}
}
