package com.deloitte;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class EmpListTest {

	public static void main(String[] args) {
		List<Emp> empList = new ArrayList<>();
		empList.add(new Emp(112, "Anshul", 7868805672L));
		empList.add(new Emp(111, "Anshu", 7868805673L));
		empList.add(new Emp(113, "Ansh", 7868805674L));
		empList.add(new Emp(114, "Ans", 7868805675L));
		empList.add(new Emp(115, "An", 7868805676L));
		empList.add(new Emp(116, "A", 7868805677L));
		System.out.println(empList);
		//Sorting it
		System.out.println("Sorted By ID");
		Collections.sort(empList, new EmpComparator(OrderField.ID));
		System.out.println(empList);
		System.out.println("Sorted By name");
//		Collections.sort(empList, new EmpComparator(OrderField.NAME));
		Collections.sort(empList, (e1, e2)->e1.getName().compareTo(e2.getName()));
		System.out.println(empList);
		System.out.println("Sorted By Mobile");
		Collections.sort(empList, new EmpComparator(OrderField.MOBILE));
		System.out.println(empList);
	}

}
