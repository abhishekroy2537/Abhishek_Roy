package com.deloitte;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class ListTest {
	public static void main(String[] args) {
		List<String> colorList = new CopyOnWriteArrayList<>(); 
//				new ArrayList<>();
		String[] colorArray = { "Red", "Green", "Blue", "Pink", "Orange"};
		for (String color : colorArray) {
			colorList.add(color); // List is Ordered and Indexed
		}
		System.out.println(colorList);
		String[] deleteArray = {"green", "blue"};
		List<String> deleteList = Arrays.asList(deleteArray); //It is a fixed list
		Iterator<String> iter = colorList.iterator();
		int ctr = 0;
		while(iter.hasNext()) {
			ctr++;
			String color = iter.next();
			if(deleteList.contains(color.toLowerCase())) {
//				iter.remove(); //It will remove the original object
				colorList.remove(color);
				if(ctr == 2) {
					colorList.add("Yellow");
				}
			}
		}
		System.out.println(colorList);
		
//		System.out.println(colorList.get(3));
//		System.out.println(colorList.remove(3));
//		System.out.println(colorList);
//		System.out.println(colorList.size());
//		colorList.add(0, "Blue");
//		System.out.println(colorList);
//		//Sorting Using Collections Class
//		Collections.sort(colorList, Collections.reverseOrder()); // Other parameter is Comparator.
//		System.out.println(colorList);
		
	}
}
