package com.deloitte.dao;

import com.deloitte.exception.BankingException;
import com.deloitte.util.BankingMessage;

public class BankingDaoImpl implements BankingDao {
	private double balance;
	private static final double MIN_BALANCE = 1000;

	@Override
	public boolean depositAmount(double amount) {
		balance += amount;
		return true;
	}

	@Override
	public double getBalance() {
		
		return balance;
	}

	@Override
	public boolean withdrawAmount(double amount) throws BankingException {
		double temp = balance - amount;
		if (temp < MIN_BALANCE) {
			throw new BankingException(BankingMessage.INSUFFICIENT_BALANCE);
		} else {
			balance = temp;
			return true;
		}
	}

}
